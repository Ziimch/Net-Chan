package com.netlab.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.TrafficStats
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

typealias Out = (String) -> Unit

fun f1(d: Double): String = String.format(Locale.US, "%.1f", d)
fun f2(d: Double): String = String.format(Locale.US, "%.2f", d)

object NetTools {

    val COMMON_PORTS = mapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS", 80 to "HTTP",
        110 to "POP3", 143 to "IMAP", 443 to "HTTPS", 445 to "SMB", 465 to "SMTPS",
        587 to "SMTP-Submission", 993 to "IMAPS", 995 to "POP3S", 1433 to "MSSQL",
        1723 to "PPTP", 3306 to "MySQL", 3389 to "RDP", 5432 to "PostgreSQL",
        5900 to "VNC", 6379 to "Redis", 8080 to "HTTP-Alt", 8443 to "HTTPS-Alt", 27017 to "MongoDB"
    )

    // ---------------------------------------------------------------- helpers

    private val timeRe = Regex("time[=<]\\s*([0-9.]+)")
    private val fromRe = Regex("[Ff]rom ([0-9a-fA-F:.]+)")
    private val replyRe = Regex("bytes from")

    class IcmpResult(val ms: Double?, val hop: String?, val reached: Boolean)

    /** Ping ICMP 1x lewat binary sistem. null = tidak tersedia di perangkat. */
    fun icmp(ip: String, ttl: Int? = null, timeoutSec: Int = 2): IcmpResult? = try {
        val bin = if (ip.contains(':')) "/system/bin/ping6" else "/system/bin/ping"
        val cmd = mutableListOf(bin, "-c", "1", "-W", timeoutSec.toString())
        if (ttl != null) { cmd.add("-t"); cmd.add(ttl.toString()) }
        cmd.add(ip)
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        val text = p.inputStream.bufferedReader().readText()
        p.waitFor(timeoutSec + 2L, TimeUnit.SECONDS)
        p.destroy()
        if (text.isBlank() || text.contains("not found", true) || text.contains("Permission denied", true)) null
        else IcmpResult(
            timeRe.find(text)?.groupValues?.get(1)?.toDoubleOrNull(),
            fromRe.find(text)?.groupValues?.get(1)?.trimEnd(':'),
            replyRe.containsMatchIn(text)
        )
    } catch (e: Exception) { null }

    /** Waktu TCP connect (ms) atau null jika gagal. */
    fun tcp(host: String, port: Int, timeout: Int = 2000): Double? {
        val s = Socket()
        val t = System.nanoTime()
        return try {
            s.connect(InetSocketAddress(host, port), timeout)
            (System.nanoTime() - t) / 1e6
        } catch (e: Exception) { null } finally { runCatching { s.close() } }
    }

    private fun resolve(host: String, out: Out): String? = try {
        InetAddress.getByName(host).hostAddress
    } catch (e: Exception) { out("Host tidak dapat di-resolve: $host"); null }

    private fun summary(sent: Int, t: List<Double>, out: Out) {
        out(""); out("--- statistik ---")
        val loss = (sent - t.size) * 100.0 / sent
        out("Dikirim=$sent  Diterima=${t.size}  Loss=${f1(loss)}%")
        if (t.isEmpty()) return
        val avg = t.average()
        val jitter = if (t.size > 1) t.zipWithNext { a, b -> abs(b - a) }.average() else 0.0
        val sd = sqrt(t.map { (it - avg) * (it - avg) }.average())
        out("Min/Rata2/Max = ${f1(t.min())}/${f1(avg)}/${f1(t.max())} ms")
        out("Jitter=${f1(jitter)} ms   StdDev=${f1(sd)} ms")
        val verdict = when {
            loss > 5 || avg > 150 -> "Kurang baik (lag terasa untuk game/video call)"
            loss > 0 || avg > 60 -> "Cukup baik"
            else -> "Sangat baik (cocok untuk game online & video call)"
        }
        out("Kualitas: $verdict")
    }

    // ------------------------------------------------------------------ ping

    suspend fun ping(host: String, count: Int, out: Out) = withContext(Dispatchers.IO) {
        val ip = resolve(host, out) ?: return@withContext
        out("PING $host ($ip), $count paket")
        val times = ArrayList<Double>()
        var useTcp = false
        for (i in 1..count) {
            ensureActive()
            var ms: Double? = null
            if (!useTcp) {
                val r = icmp(ip)
                if (r == null) {
                    useTcp = true
                    out("(ICMP tidak tersedia di perangkat ini, memakai TCP connect ke port 443)")
                } else ms = r.ms
            }
            if (useTcp) ms = tcp(ip, 443, 2000)
            if (ms != null) { times.add(ms); out("#$i  dari $ip  waktu=${f1(ms)} ms") }
            else out("#$i  timeout")
            if (i < count) delay(1000)
        }
        summary(count, times, out)
    }

    // ------------------------------------------------------------ traceroute

    suspend fun trace(host: String, maxHops: Int, out: Out) = withContext(Dispatchers.IO) {
        val ip = resolve(host, out) ?: return@withContext
        out("Traceroute ke $host ($ip), maks $maxHops hop")
        out("(waktu per hop adalah perkiraan, termasuk overhead proses ping)")
        for (ttl in 1..maxHops) {
            ensureActive()
            val t0 = System.nanoTime()
            val r = icmp(ip, ttl, 2)
            val wall = (System.nanoTime() - t0) / 1e6
            if (r == null) {
                out("Traceroute tidak didukung perangkat ini (binary ping tidak tersedia).")
                return@withContext
            }
            val no = ttl.toString().padStart(2)
            if (r.hop == null) out("$no  *  (timeout)")
            else out("$no  ${r.hop}  ~${f1(r.ms ?: wall)} ms")
            if (r.reached) { out("Tujuan tercapai dalam $ttl hop."); break }
        }
    }

    // ------------------------------------------------------------------- dns

    suspend fun dns(host: String, out: Out) = withContext(Dispatchers.IO) {
        val t = System.nanoTime()
        try {
            val all = InetAddress.getAllByName(host)
            out("Waktu resolusi: ${f1((System.nanoTime() - t) / 1e6)} ms")
            all.forEach {
                out((if (it is Inet6Address) "AAAA  " else "A     ") + it.hostAddress)
            }
            val rev = all.first().canonicalHostName
            out("Reverse DNS: $rev")
        } catch (e: Exception) {
            out("Gagal resolve '$host': ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------- port scan

    fun parsePorts(input: String): List<Int> {
        val s = input.trim()
        if (s.isEmpty() || s.equals("common", true)) return COMMON_PORTS.keys.sorted()
        val set = LinkedHashSet<Int>()
        for (part in s.split(',')) {
            val p = part.trim()
            if (p.contains('-')) {
                val a = p.substringBefore('-').trim().toIntOrNull() ?: continue
                val b = p.substringAfter('-').trim().toIntOrNull() ?: continue
                for (x in a..b) if (x in 1..65535 && set.size < 5000) set.add(x)
            } else p.toIntOrNull()?.takeIf { it in 1..65535 }?.let { set.add(it) }
        }
        return set.toList()
    }

    suspend fun portScan(host: String, ports: List<Int>, out: Out) = withContext(Dispatchers.IO) {
        val ip = resolve(host, out) ?: return@withContext
        out("Memindai ${ports.size} port di $host ($ip)...")
        val sem = Semaphore(48)
        val open = AtomicInteger(0)
        coroutineScope {
            ports.map { p ->
                async {
                    sem.withPermit {
                        val ms = tcp(ip, p, 1500)
                        if (ms != null) {
                            open.incrementAndGet()
                            out("TERBUKA  $p/tcp  ${COMMON_PORTS[p] ?: ""}  (${f1(ms)} ms)")
                        }
                    }
                }
            }.awaitAll()
        }
        out("Selesai: ${open.get()} terbuka dari ${ports.size} port.")
    }

    // -------------------------------------------------------------- LAN scan

    private fun probe(ip: String): Pair<Boolean, List<Int>> {
        var alive = false
        val open = ArrayList<Int>()
        for (p in intArrayOf(80, 443, 445, 22, 53, 8080)) {
            val sk = Socket()
            try {
                sk.connect(InetSocketAddress(ip, p), 250)
                open.add(p)
                alive = true
            } catch (e: ConnectException) {
                if (e.message?.contains("refused", true) == true) alive = true
            } catch (e: Exception) {
            } finally { runCatching { sk.close() } }
        }
        if (!alive) alive = runCatching { InetAddress.getByName(ip).isReachable(300) }.getOrDefault(false)
        return Pair(alive, open)
    }

    suspend fun lanScan(ctx: Context, out: Out) = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork)
        val me = lp?.linkAddresses?.map { it.address }?.firstOrNull { it is Inet4Address }?.hostAddress
        if (me == null) { out("Tidak terhubung ke jaringan IPv4 lokal."); return@withContext }
        val gw = lp?.routes?.filter { it.isDefaultRoute }?.mapNotNull { it.gateway }
            ?.firstOrNull { it is Inet4Address }?.hostAddress
        val base = me.substringBeforeLast('.')
        out("IP perangkat: $me   Gateway: ${gw ?: "-"}")
        out("Memindai $base.1 - $base.254 beserta port umum (sekitar 10-20 detik)...")
        val sem = Semaphore(48)
        val found = ConcurrentHashMap<Int, String>()
        coroutineScope {
            (1..254).map { n ->
                async {
                    sem.withPermit {
                        val ip = "$base.$n"
                        val (alive, open) = probe(ip)
                        if (alive) {
                            val name = runCatching { InetAddress.getByName(ip).canonicalHostName }.getOrDefault(ip)
                            val tags = StringBuilder()
                            if (name != ip) tags.append("  ($name)")
                            if (ip == gw) tags.append("  [Gateway/Router]")
                            if (ip == me) tags.append("  [perangkat ini]")
                            if (open.isNotEmpty()) {
                                tags.append("\n      port: ").append(open.joinToString(", ") { "$it/${COMMON_PORTS[it] ?: "?"}" })
                            }
                            found[n] = ip + tags
                        }
                    }
                }
            }.awaitAll()
        }
        out("Ditemukan ${found.size} perangkat aktif:")
        found.keys.sorted().forEach { out("  " + found[it]) }
        out("")
        out("Catatan: perangkat yang memblokir semua koneksi mungkin tidak terdeteksi.")
    }

    // ------------------------------------------------------------ speed test

    class SpeedResult(val dl: Double, val ul: Double, val ping: Double, val jitter: Double, val loadedPing: Double)

    suspend fun speedTest(out: Out): SpeedResult? = withContext(Dispatchers.IO) {
        out("Server: speed.cloudflare.com")
        val lat = ArrayList<Double>()
        repeat(5) { tcp("speed.cloudflare.com", 443, 3000)?.let { lat.add(it) }; delay(150) }
        if (lat.isEmpty()) {
            out("Tidak dapat terhubung ke server test. Cek koneksi internet.")
            return@withContext null
        }
        val idle = lat.average()
        val jitter = if (lat.size > 1) lat.zipWithNext { a, b -> abs(a - b) }.average() else 0.0
        out("Latensi (idle): min ${f1(lat.min())} / rata2 ${f1(idle)} ms, jitter ${f1(jitter)} ms")

        val dlLoad: MutableList<Double> = java.util.Collections.synchronizedList(ArrayList<Double>())
        out(""); out("Download (4 koneksi paralel, 8 detik)...")
        val dl = transfer(8000, true, out, dlLoad)
        out("Download: ${f2(dl)} Mbps")
        if (dlLoad.isNotEmpty()) out("Latensi saat download: ${f1(dlLoad.average())} ms (+${f1(dlLoad.average() - idle)} ms)")

        val ulLoad: MutableList<Double> = java.util.Collections.synchronizedList(ArrayList<Double>())
        out(""); out("Upload (4 koneksi paralel, 6 detik)...")
        val ul = transfer(6000, false, out, ulLoad)
        out("Upload: ${f2(ul)} Mbps")
        if (ulLoad.isNotEmpty()) out("Latensi saat upload: ${f1(ulLoad.average())} ms (+${f1(ulLoad.average() - idle)} ms)")

        val worst = listOf(dlLoad, ulLoad).filter { it.isNotEmpty() }.maxOfOrNull { it.average() } ?: idle
        val delta = worst - idle
        val grade = when {
            delta < 30 -> "A (sangat baik)"
            delta < 60 -> "B (baik)"
            delta < 200 -> "C (sedang, bisa lag saat ada unduhan besar)"
            delta < 400 -> "D (buruk)"
            else -> "F (parah)"
        }
        out(""); out("Bufferbloat: $grade  (latensi naik ${f1(delta)} ms saat jaringan penuh)")
        out(""); out("RINGKASAN  ↓ ${f1(dl)} Mbps | ↑ ${f1(ul)} Mbps | ping ${f1(idle)} ms | bufferbloat $grade")
        SpeedResult(dl, ul, idle, jitter, worst)
    }

    private suspend fun transfer(durationMs: Long, down: Boolean, out: Out, loaded: MutableList<Double>): Double = coroutineScope {
        val total = AtomicLong(0)
        val start = System.nanoTime()
        val deadline = start + durationMs * 1_000_000
        fun mbps() = total.get() * 8.0 / 1e6 / max((System.nanoTime() - start) / 1e9, 0.001)
        val ticker = launch { while (isActive) { delay(1000); out("  ... ${f1(mbps())} Mbps") } }
        val probe = launch(Dispatchers.IO) {
            delay(1000)
            while (isActive) { tcp("speed.cloudflare.com", 443, 2000)?.let { loaded.add(it) }; delay(400) }
        }
        val workers = (1..4).map {
            launch(Dispatchers.IO) { if (down) downloadLoop(total, deadline) else uploadLoop(total, deadline) }
        }
        workers.joinAll()
        ticker.cancel()
        probe.cancel()
        mbps()
    }

    private fun CoroutineScope.downloadLoop(total: AtomicLong, deadline: Long) {
        val buf = ByteArray(64 * 1024)
        while (isActive && System.nanoTime() < deadline) {
            var c: HttpURLConnection? = null
            try {
                val conn = URL("https://speed.cloudflare.com/__down?bytes=25000000").openConnection() as HttpURLConnection
                conn.connectTimeout = 5000; conn.readTimeout = 5000
                c = conn
                val ins = conn.inputStream
                while (isActive && System.nanoTime() < deadline) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total.addAndGet(n.toLong())
                }
                ins.close()
            } catch (e: Exception) { return } finally { c?.disconnect() }
        }
    }

    private fun CoroutineScope.uploadLoop(total: AtomicLong, deadline: Long) {
        val chunk = ByteArray(32 * 1024) { (it * 31).toByte() }
        val size = 4 * 1024 * 1024
        while (isActive && System.nanoTime() < deadline) {
            var c: HttpURLConnection? = null
            try {
                val conn = URL("https://speed.cloudflare.com/__up").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"; conn.doOutput = true
                conn.connectTimeout = 5000; conn.readTimeout = 10000
                conn.setFixedLengthStreamingMode(size)
                conn.setRequestProperty("Content-Type", "application/octet-stream")
                c = conn
                val os = conn.outputStream
                var sent = 0
                while (sent < size && isActive && System.nanoTime() < deadline) {
                    os.write(chunk); sent += chunk.size; total.addAndGet(chunk.size.toLong())
                }
                if (sent < size) return
                os.flush()
                conn.responseCode
            } catch (e: Exception) { return } finally { c?.disconnect() }
        }
    }

    // ---------------------------------------------------------- HTTP / layanan

    val DEFAULT_SITES = listOf(
        "https://www.google.com", "https://www.cloudflare.com", "https://www.youtube.com",
        "https://www.facebook.com", "https://www.instagram.com", "https://www.tiktok.com",
        "https://web.whatsapp.com", "https://www.tokopedia.com", "https://www.detik.com"
    )

    suspend fun httpCheck(urls: List<String>, out: Out) = withContext(Dispatchers.IO) {
        out(String.format(Locale.US, "%-22s %-10s %-10s %s", "Situs", "DNS(ms)", "TTFB(ms)", "HTTP"))
        for (u in urls) {
            ensureActive()
            val host = URL(u).host
            try {
                val t0 = System.nanoTime()
                InetAddress.getByName(host)
                val dnsMs = (System.nanoTime() - t0) / 1e6
                val t1 = System.nanoTime()
                val c = URL(u).openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000; c.instanceFollowRedirects = true
                val code = c.responseCode
                val ttfb = (System.nanoTime() - t1) / 1e6
                c.disconnect()
                out(String.format(Locale.US, "%-22s %-10s %-10s %d", host.removePrefix("www."), f1(dnsMs), f1(ttfb), code))
            } catch (e: Exception) {
                out(String.format(Locale.US, "%-22s GAGAL (%s)", host.removePrefix("www."), e.javaClass.simpleName))
            }
        }
        out(""); out("Selesai.")
    }

    // --------------------------------------------------------------- monitor

    private fun fmtBytes(b: Long): String = when {
        b >= 1_048_576 -> f2(b / 1_048_576.0) + " MB"
        b >= 1024 -> f1(b / 1024.0) + " KB"
        else -> "$b B"
    }

    suspend fun monitor(out: Out) = withContext(Dispatchers.IO) {
        var rx = TrafficStats.getTotalRxBytes()
        var tx = TrafficStats.getTotalTxBytes()
        out("Memantau lalu lintas seluruh perangkat (tekan Stop untuk berhenti)")
        while (isActive) {
            delay(1000)
            val r = TrafficStats.getTotalRxBytes()
            val t = TrafficStats.getTotalTxBytes()
            out("↓ ${fmtBytes(r - rx)}/s    ↑ ${fmtBytes(t - tx)}/s")
            rx = r; tx = t
        }
    }
}
