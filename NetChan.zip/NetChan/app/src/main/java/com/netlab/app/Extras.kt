package com.netlab.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

object Extras {

    // ----------------------------------------------------- Wake-on-LAN

    private fun parseMac(input: String): ByteArray? {
        val hex = input.trim().replace(Regex("[:\\-. ]"), "")
        if (hex.length != 12 || !hex.matches(Regex("[0-9a-fA-F]+"))) return null
        return ByteArray(6) { ((hex.substring(it * 2, it * 2 + 2)).toInt(16)).toByte() }
    }

    suspend fun wakeOnLan(mac: String, ip: String, port: Int, out: Out) = withContext(Dispatchers.IO) {
        val addr = parseMac(mac)
        if (addr == null) { out("Format MAC tidak valid. Contoh: AA:BB:CC:DD:EE:FF"); return@withContext }
        val packet = ByteArray(6 + 16 * 6)
        for (i in 0 until 6) packet[i] = 0xFF.toByte()
        for (i in 0 until 16) System.arraycopy(addr, 0, packet, 6 + i * 6, 6)
        val target = ip.trim().ifEmpty { "255.255.255.255" }
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                s.send(DatagramPacket(packet, packet.size, InetAddress.getByName(target), port))
            }
            out("Magic packet terkirim ke $target:$port untuk MAC ${mac.uppercase()}")
            out("")
            out("Jika perangkat tidak menyala, pastikan:")
            out("- Wake-on-LAN diaktifkan di BIOS/pengaturan jaringan perangkat tujuan")
            out("- HP terhubung ke Wi-Fi/LAN yang sama dengan perangkat tujuan")
            out("- Gunakan IP broadcast jaringan (misalnya 192.168.1.255) jika 255.255.255.255 tidak berhasil")
        } catch (e: Exception) {
            out("Gagal mengirim: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    // ----------------------------------------------------- Subnet calculator

    private fun parseIp(ip: String): Int? {
        val p = ip.trim().split('.')
        if (p.size != 4) return null
        val b = p.map { it.toIntOrNull() ?: return null }
        if (b.any { it !in 0..255 }) return null
        return (b[0] shl 24) or (b[1] shl 16) or (b[2] shl 8) or b[3]
    }

    private fun ipText(v: Int) = "${(v ushr 24) and 0xFF}.${(v ushr 16) and 0xFF}.${(v ushr 8) and 0xFF}.${v and 0xFF}"

    fun subnetCalc(cidrInput: String, out: Out) {
        val input = cidrInput.trim()
        val parts = input.split('/')
        if (parts.size != 2) { out("Format: IP/prefix, contoh 192.168.1.10/24"); return }
        val ipVal = parseIp(parts[0])
        val prefix = parts[1].toIntOrNull()
        if (ipVal == null || prefix == null || prefix !in 0..32) { out("Format tidak valid. Contoh: 192.168.1.10/24"); return }

        val mask = if (prefix == 0) 0 else (-1 shl (32 - prefix))
        val network = ipVal and mask
        val broadcast = network or mask.inv()
        val hostBits = 32 - prefix
        val totalHosts = if (hostBits <= 0) 1L else 1L shl hostBits
        val usable = if (prefix >= 31) totalHosts else totalHosts - 2

        out("IP           : ${ipText(ipVal)}")
        out("Prefix       : /$prefix")
        out("Subnet mask  : ${ipText(mask)}")
        out("Wildcard mask: ${ipText(mask.inv())}")
        out("Network      : ${ipText(network)}")
        out("Broadcast    : ${ipText(broadcast)}")
        if (prefix < 31) {
            out("Range host   : ${ipText(network + 1)} - ${ipText(broadcast - 1)}")
        } else {
            out("Range host   : ${ipText(network)} - ${ipText(broadcast)} (point-to-point/host tunggal)")
        }
        out("Total host   : $totalHosts   Usable: $usable")
        out("")
        out("Kelas lama   : " + when ((ipVal ushr 28) and 0xF) {
            in 0..7 -> "A"; in 8..11 -> "B"; in 12..13 -> "C"; 14 -> "D (multicast)"; else -> "E"
        })
        out("Privat (RFC1918): " + (
            (ipVal ushr 24) and 0xFF == 10 ||
                ((ipVal ushr 24) and 0xFF == 172 && (ipVal ushr 16) and 0xFF in 16..31) ||
                ((ipVal ushr 24) and 0xFF == 192 && (ipVal ushr 16) and 0xFF == 168)
            ))
    }

    // ----------------------------------------------------- Banner grab

    private val PROBES = mapOf(
        80 to "HEAD / HTTP/1.0\r\nHost: %HOST%\r\nUser-Agent: Net-Chan\r\n\r\n",
        8080 to "HEAD / HTTP/1.0\r\nHost: %HOST%\r\nUser-Agent: Net-Chan\r\n\r\n",
        25 to null, 21 to null, 22 to null, 110 to null, 143 to null
    )

    private fun grabOne(host: String, port: Int, timeout: Int = 2500): String {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), timeout)
            s.soTimeout = timeout
            val probe = PROBES[port]?.replace("%HOST%", host)
            if (probe != null) s.getOutputStream().write(probe.toByteArray())
            val buf = ByteArray(1024)
            val n = s.getInputStream().read(buf)
            return if (n > 0) String(buf, 0, n, Charsets.ISO_8859_1).trimEnd() else "(terhubung, tidak ada banner)"
        }
    }

    suspend fun bannerGrab(host: String, portsInput: String, out: Out) = withContext(Dispatchers.IO) {
        if (host.isBlank()) { out("Masukkan host/IP terlebih dahulu."); return@withContext }
        val requested = NetTools.parsePorts(portsInput.ifBlank { "21,22,23,25,80,110,143,3306,8080" })
        val tlsPorts = setOf(443, 8443, 993, 995, 465)
        val ports = requested.filter { it !in tlsPorts }
        val skipped = requested.filter { it in tlsPorts }
        if (skipped.isNotEmpty()) {
            out("Melewati port ${skipped.joinToString(", ")}: memakai TLS, bukan banner teks biasa. Cek lewat tab Web/SSL.")
            out("")
        }
        if (ports.isEmpty()) { out("Tidak ada port tersisa untuk dipindai."); return@withContext }
        out("Mengambil banner dari $host, ${ports.size} port...")
        out("")
        val sem = Semaphore(16)
        val results = java.util.Collections.synchronizedMap(LinkedHashMap<Int, String>())
        coroutineScope {
            ports.map { p ->
                async {
                    sem.withPermit {
                        try {
                            results[p] = grabOne(host, p)
                        } catch (e: java.net.ConnectException) {
                        } catch (e: java.net.SocketTimeoutException) {
                        } catch (e: Exception) {
                        }
                    }
                }
            }.awaitAll()
        }
        if (results.isEmpty()) { out("Tidak ada port terbuka yang membalas."); return@withContext }
        results.toSortedMap().forEach { (p, banner) ->
            out("Port $p (${NetTools.COMMON_PORTS[p] ?: "?"}):")
            banner.lines().take(6).forEach { out("   $it") }
            out("")
        }
    }
}
