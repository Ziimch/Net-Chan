package com.netlab.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Riwayat hasil Speed Test (disimpan lokal di perangkat, maks 100 data). */
object History {
    private const val PREF = "netchan"
    private const val KEY = "speed_history"

    fun add(ctx: Context, r: NetTools.SpeedResult, net: String) {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]"))
        arr.put(
            JSONObject().put("t", System.currentTimeMillis()).put("dl", r.dl).put("ul", r.ul)
                .put("ping", r.ping).put("jit", r.jitter).put("load", r.loadedPing).put("net", net)
        )
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 100) until arr.length()) trimmed.put(arr.get(i))
        sp.edit().putString(KEY, trimmed.toString()).apply()
    }

    fun lines(ctx: Context): List<String> {
        val sp = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val arr = JSONArray(sp.getString(KEY, "[]"))
        if (arr.length() == 0) return emptyList()
        val fmt = SimpleDateFormat("dd MMM HH:mm", Locale("id", "ID"))
        val out = ArrayList<String>()
        var sumD = 0.0
        var sumU = 0.0
        var bestD = 0.0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            sumD += o.getDouble("dl"); sumU += o.getDouble("ul"); bestD = maxOf(bestD, o.getDouble("dl"))
        }
        out.add("Total ${arr.length()} tes | rata2 ↓ ${f1(sumD / arr.length())} Mbps, ↑ ${f1(sumU / arr.length())} Mbps | terbaik ↓ ${f1(bestD)} Mbps")
        out.add("")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            out.add("${fmt.format(Date(o.getLong("t")))}  ${o.optString("net")}")
            out.add("   ↓ ${f1(o.getDouble("dl"))}  ↑ ${f1(o.getDouble("ul"))} Mbps   ping ${f1(o.getDouble("ping"))} ms   jitter ${f1(o.getDouble("jit"))} ms   saat unduh ${f1(o.optDouble("load", 0.0))} ms")
        }
        return out
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
