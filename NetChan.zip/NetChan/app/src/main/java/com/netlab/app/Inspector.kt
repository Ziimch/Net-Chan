package com.netlab.app

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URL
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class SsdpDevice {
    var server: String = ""
    var location: String = ""
    val st = LinkedHashSet<String>()
}

object Inspector {

    // ------------------------------------------------------- Web / SSL

    suspend fun web(input: String, out: Out) = withContext(Dispatchers.IO) {
        var host = input.trim().removePrefix("https://").removePrefix("http://").substringBefore('/')
        var port = 443
        if (host.count { it == ':' } == 1) {
            port = host.substringAfter(':').toIntOrNull() ?: 443
            host = host.substringBefore(':')
        }
        if (host.isBlank()) { out("Masukkan domain, misalnya www.google.com"); return@withContext }
        out("== ANALISIS $host:$port ==")

        val t0 = System.nanoTime()
        val addrs = try { InetAddress.getAllByName(host) } catch (e: Exception) {
            out("DNS gagal: ${e.javaClass.simpleName}"); return@withContext
        }
        out("DNS          : ${f1((System.nanoTime() - t0) / 1e6)} ms  -> ${addrs.joinToString { it.hostAddress ?: "" }}")

        val sock = Socket()
        val t1 = System.nanoTime()
        try {
            sock.connect(InetSocketAddress(addrs[0], port), 5000)
        } catch (e: Exception) {
            out("TCP gagal: ${e.javaClass.simpleName} ${e.message}"); return@withContext
        }
        out("TCP connect  : ${f1((System.nanoTime() - t1) / 1e6)} ms  (${addrs[0].hostAddress})")

        try {
            val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(sock, host, port, true) as SSLSocket
            ssl.soTimeout = 5000
            val t2 = System.nanoTime()
            ssl.startHandshake()
            val hs = (System.nanoTime() - t2) / 1e6
            val ses = ssl.session
            out("TLS handshake: ${f1(hs)} ms")
            out("Protokol     : ${ses.protocol}")
            out("Cipher suite : ${ses.cipherSuite}")
            out("Hostname cocok: ${HttpsURLConnection.getDefaultHostnameVerifier().verify(host, ses)}")
            val chain = ses.peerCertificates.filterIsInstance<X509Certificate>()
            out("Rantai sertifikat: ${chain.size}")
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            chain.forEachIndexed { i, c ->
                val days = (c.notAfter.time - System.currentTimeMillis()) / 86_400_000L
                out("")
                out(if (i == 0) "Sertifikat server:" else "Sertifikat perantara/root #$i:")
                out("  Subjek  : ${c.subjectX500Principal.name.take(110)}")
                out("  Penerbit: ${c.issuerX500Principal.name.take(110)}")
                out("  Berlaku : ${df.format(c.notBefore)} s/d ${df.format(c.notAfter)}  (${if (days >= 0) "$days hari lagi" else "KEDALUWARSA"})")
                val k = c.publicKey
                val bits = (k as? RSAPublicKey)?.let { " ${it.modulus.bitLength()} bit" } ?: ""
                out("  Kunci   : ${k.algorithm}$bits   Tanda tangan: ${c.sigAlgName}")
                if (i == 0) {
                    val san = try {
                        c.subjectAlternativeNames?.mapNotNull { if (it[0] == 2) it[1].toString() else null }
                    } catch (e: Exception) { null }
                    if (!san.isNullOrEmpty()) {
                        out("  SAN     : ${san.take(8).joinToString()}${if (san.size > 8) " (+${san.size - 8})" else ""}")
                    }
                }
            }
            ssl.close()
        } catch (e: Exception) {
            out("TLS gagal: ${e.javaClass.simpleName}: ${e.message}")
        } finally {
            runCatching { sock.close() }
        }

        out("")
        out("== HTTP ==")
        try {
            val url = URL("https://$host${if (port != 443) ":$port" else ""}/")
            val c = url.openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 7000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Net-Chan/1.1")
            val t3 = System.nanoTime()
            val code = c.responseCode
            val ttfb = (System.nanoTime() - t3) / 1e6
            out("Status : $code ${c.responseMessage ?: ""}  (waktu ${f1(ttfb)} ms, termasuk koneksi baru)")
            val loc = c.getHeaderField("Location")
            if (loc != null) out("Redirect: $loc")
            out("")
            c.headerFields.filterKeys { it != null }.entries.take(30).forEach { (k, v) ->
                out("  $k: ${v.joinToString("; ").take(120)}")
            }
            out("")
            out("Header keamanan:")
            listOf(
                "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
                "X-Content-Type-Options", "Referrer-Policy"
            ).forEach { n ->
                out("  ${if (c.getHeaderField(n) != null) "ADA        " else "tidak ada  "} $n")
            }
            c.disconnect()
        } catch (e: Exception) {
            out("HTTP gagal: ${e.javaClass.simpleName}: ${e.message}")
        }
        out("")
        out("Selesai.")
    }

    // ------------------------------------------------------- IP lookup

    suspend fun ipLookup(target: String, out: Out) = withContext(Dispatchers.IO) {
        val t = target.trim()
        var ip = ""
        if (t.isNotEmpty()) {
            val all = try { InetAddress.getAllByName(t) } catch (e: Exception) {
                out("Tidak dapat resolve '$t'"); return@withContext
            }
            if (all.size > 1 || all[0].hostAddress != t) {
                out("Alamat untuk $t: ${all.joinToString { it.hostAddress ?: "" }}")
            }
            ip = all.firstOrNull { it is Inet4Address }?.hostAddress ?: all[0].hostAddress ?: ""
            out("Memeriksa: $ip")
            out("")
        }
        try {
            val c = URL("https://ipwho.is/$ip").openConnection() as HttpURLConnection
            c.connectTimeout = 5000
            c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            c.disconnect()
            if (!j.optBoolean("success", true)) {
                out("Gagal: ${j.optString("message")}")
            } else {
                val conn = j.optJSONObject("connection")
                val tz = j.optJSONObject("timezone")
                val shown = j.optString("ip")
                out("IP          : $shown (${j.optString("type")})")
                out("Negara      : ${j.optString("country")} ${j.optJSONObject("flag")?.optString("emoji") ?: ""} (${j.optString("country_code")})")
                out("Benua       : ${j.optString("continent")}")
                out("Region/Kota : ${j.optString("region")} / ${j.optString("city")}")
                out("Kode pos    : ${j.optString("postal")}")
                out("Koordinat   : ${j.optDouble("latitude")}, ${j.optDouble("longitude")} (perkiraan)")
                out("ASN         : AS${conn?.optInt("asn")}")
                out("Organisasi  : ${conn?.optString("org")}")
                out("ISP         : ${conn?.optString("isp")}")
                out("Domain      : ${conn?.optString("domain")}")
                out("Zona waktu  : ${tz?.optString("id")} (UTC ${tz?.optString("utc")})")
                out("Waktu lokal : ${tz?.optString("current_time")}")
                val rev = runCatching { InetAddress.getByName(shown).canonicalHostName }.getOrNull()
                if (rev != null && rev != shown) out("Reverse DNS : $rev")
            }
        } catch (e: Exception) {
            out("Gagal mengambil data: ${e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------- SSDP

    suspend fun ssdp(ctx: Context, out: Out) = withContext(Dispatchers.IO) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wm.createMulticastLock("netchan-ssdp")
        lock.setReferenceCounted(false)
        lock.acquire()
        try {
            out("Mengirim SSDP M-SEARCH (UPnP) ke jaringan lokal, tunggu sekitar 6 detik...")
            val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n").toByteArray()
            val seen = LinkedHashMap<String, SsdpDevice>()
            DatagramSocket().use { s ->
                s.soTimeout = 1000
                s.broadcast = true
                val grp = InetAddress.getByName("239.255.255.250")
                for (i in 0 until 2) s.send(DatagramPacket(msg, msg.size, grp, 1900))
                val end = System.currentTimeMillis() + 6000
                val buf = ByteArray(2048)
                while (isActive && System.currentTimeMillis() < end) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val ip = p.address.hostAddress ?: continue
                        val dev = seen.getOrPut(ip) { SsdpDevice() }
                        String(p.data, 0, p.length).lines().forEach { line ->
                            val i = line.indexOf(':')
                            if (i > 0) {
                                val k = line.substring(0, i).trim().uppercase()
                                val v = line.substring(i + 1).trim()
                                when (k) {
                                    "SERVER" -> { dev.server = v }
                                    "LOCATION" -> { dev.location = v }
                                    "ST", "NT" -> { dev.st.add(v) }
                                }
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                    }
                }
            }
            if (seen.isEmpty()) {
                out("Tidak ada perangkat UPnP yang merespons.")
                out("(Pastikan terhubung ke Wi-Fi. Sebagian router memblokir multicast.)")
                return@withContext
            }
            val info = ConcurrentHashMap<String, String>()
            val locs = seen.values.map { it.location }.filter { it.startsWith("http") }.distinct().take(20)
            coroutineScope {
                locs.map { loc ->
                    async {
                        runCatching {
                            val c = URL(loc).openConnection() as HttpURLConnection
                            c.connectTimeout = 1500
                            c.readTimeout = 1500
                            val x = c.inputStream.bufferedReader().readText().take(20000)
                            c.disconnect()
                            val fn = Regex("<friendlyName>(.*?)</friendlyName>").find(x)?.groupValues?.get(1)
                            val mf = Regex("<manufacturer>(.*?)</manufacturer>").find(x)?.groupValues?.get(1)
                            val md = Regex("<modelName>(.*?)</modelName>").find(x)?.groupValues?.get(1)
                            info[loc] = listOfNotNull(fn, mf, md).joinToString(" | ")
                        }
                    }
                }.awaitAll()
            }
            out("Ditemukan ${seen.size} perangkat:")
            out("")
            seen.entries.sortedBy { e -> e.key.split('.').lastOrNull()?.toIntOrNull() ?: 0 }.forEach { (ip, d) ->
                out("$ip  ${info[d.location] ?: ""}")
                if (d.server.isNotEmpty()) out("   Server : ${d.server.take(100)}")
                if (d.location.isNotEmpty()) out("   Lokasi : ${d.location}")
                if (d.st.isNotEmpty()) out("   Layanan: ${d.st.take(4).joinToString("; ") { it.take(60) }}${if (d.st.size > 4) " (+${d.st.size - 4})" else ""}")
            }
        } finally {
            if (lock.isHeld) lock.release()
        }
    }
}
