package com.netlab.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.os.SystemClock
import android.telephony.CellIdentityNr
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoWcdma
import android.telephony.CellSignalStrengthNr
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.Inet4Address
import java.net.HttpURLConnection
import java.net.NetworkInterface
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object NetInfo {

    fun signalLabel(dbm: Int) = when {
        dbm >= -50 -> "sangat baik"
        dbm >= -60 -> "baik"
        dbm >= -70 -> "cukup"
        dbm >= -80 -> "lemah"
        else -> "sangat lemah"
    }

    fun band(f: Int) = when { f < 3000 -> "2.4 GHz"; f < 5925 -> "5 GHz"; else -> "6 GHz" }
    fun channel(f: Int) = when { f == 2484 -> 14; f < 3000 -> (f - 2407) / 5; f < 5925 -> (f - 5000) / 5; else -> (f - 5950) / 5 }

    private fun wifiStd(s: Int) = when (s) {
        4 -> "Wi-Fi 4 (802.11n)"; 5 -> "Wi-Fi 5 (802.11ac)"; 6 -> "Wi-Fi 6 (802.11ax)"
        8 -> "Wi-Fi 7 (802.11be)"; else -> "Legacy / tidak diketahui"
    }

    private fun cellType(t: Int) = when (t) {
        20 -> "5G NR"; 13 -> "4G LTE"; 15, 10, 9, 8, 3 -> "3G (HSPA/UMTS)"; 2, 1 -> "2G (EDGE/GPRS)"
        else -> "tidak diketahui ($t)"
    }

    private fun ipStr(i: Int) = "${i and 0xff}.${(i shr 8) and 0xff}.${(i shr 16) and 0xff}.${(i shr 24) and 0xff}"

    private fun widthName(w: Int) = when (w) {
        0 -> "20 MHz"; 1 -> "40 MHz"; 2 -> "80 MHz"; 3 -> "160 MHz"; 4 -> "80+80 MHz"; 5 -> "320 MHz"; else -> "?"
    }

    private fun transportsOf(c: NetworkCapabilities?): String {
        val tr = mutableListOf<String>()
        if (c?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) tr += "Wi-Fi"
        if (c?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) tr += "Seluler"
        if (c?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) tr += "Ethernet"
        if (c?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) tr += "VPN"
        if (c?.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) == true) tr += "Bluetooth"
        return tr.joinToString(" + ").ifEmpty { "tidak diketahui" }
    }

    private val CAPS = listOf(
        NetworkCapabilities.NET_CAPABILITY_INTERNET to "INTERNET",
        NetworkCapabilities.NET_CAPABILITY_VALIDATED to "VALIDATED",
        NetworkCapabilities.NET_CAPABILITY_NOT_METERED to "NOT_METERED",
        NetworkCapabilities.NET_CAPABILITY_NOT_ROAMING to "NOT_ROAMING",
        NetworkCapabilities.NET_CAPABILITY_NOT_CONGESTED to "NOT_CONGESTED",
        NetworkCapabilities.NET_CAPABILITY_NOT_SUSPENDED to "NOT_SUSPENDED",
        NetworkCapabilities.NET_CAPABILITY_NOT_VPN to "NOT_VPN",
        NetworkCapabilities.NET_CAPABILITY_NOT_RESTRICTED to "NOT_RESTRICTED",
        NetworkCapabilities.NET_CAPABILITY_TRUSTED to "TRUSTED",
        NetworkCapabilities.NET_CAPABILITY_FOREGROUND to "FOREGROUND",
        NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL to "CAPTIVE_PORTAL"
    )

    fun activeDns(ctx: Context): List<String> {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val lp = cm.getLinkProperties(cm.activeNetwork) ?: return emptyList()
        return lp.dnsServers.filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress }
    }

    @SuppressLint("MissingPermission")
    fun networkLabel(ctx: Context): String {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION")
                val ssid = try { (wm.connectionInfo.ssid ?: "").trim('"') } catch (e: Exception) { "" }
                if (ssid.isBlank() || ssid == "<unknown ssid>") "Wi-Fi" else "Wi-Fi $ssid"
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                val tm = ctx.getSystemService(TelephonyManager::class.java)
                "Seluler ${tm.networkOperatorName}"
            }
            else -> "Lainnya"
        }
    }

    @SuppressLint("MissingPermission", "NewApi")
    fun local(ctx: Context): List<String> {
        val o = mutableListOf<String>()
        o += "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})"
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork
        if (net == null) { o += "Tidak ada koneksi aktif."; return o }
        val caps = cm.getNetworkCapabilities(net)
        val lp = cm.getLinkProperties(net)

        o += ""; o += "== KONEKSI =="
        val quickStatus = when {
            caps == null -> "Tidak ada koneksi"
            !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) -> "Terhubung, tapi internet belum tervalidasi"
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL) -> "Terhubung, perlu login (captive portal)"
            else -> "Terhubung normal"
        }
        o += "Ringkasan: $quickStatus"
        o += "Tipe: ${transportsOf(caps)}"
        if (caps != null) {
            o += "Estimasi OS (turun/naik): ${caps.linkDownstreamBandwidthKbps / 1000} / ${caps.linkUpstreamBandwidthKbps / 1000} Mbps"
            if (Build.VERSION.SDK_INT >= 29 && caps.signalStrength != Int.MIN_VALUE) {
                o += "Sinyal menurut OS: ${caps.signalStrength}"
            }
            o += "Kemampuan: " + CAPS.filter { caps.hasCapability(it.first) }.joinToString(", ") { it.second }
            if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL)) {
                o += "PERHATIAN: jaringan memakai captive portal (butuh login)."
            }
            if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
                o += "PERHATIAN: internet belum tervalidasi oleh Android."
            }
        }

        if (lp != null) {
            o += ""; o += "== IP & ROUTING =="
            o += "Interface: ${lp.interfaceName}"
            lp.linkAddresses.forEach { o += "Alamat: ${it.address.hostAddress}/${it.prefixLength}" }
            val gws = lp.routes.filter { it.isDefaultRoute }.mapNotNull { it.gateway?.hostAddress }.distinct()
            o += "Gateway: ${gws.joinToString().ifEmpty { "-" }}"
            o += "DNS: ${lp.dnsServers.joinToString { it.hostAddress ?: "" }.ifEmpty { "-" }}"
            if (!lp.domains.isNullOrEmpty()) o += "Domain: ${lp.domains}"
            if (Build.VERSION.SDK_INT >= 29) o += "MTU: ${lp.mtu}"
            if (Build.VERSION.SDK_INT >= 28) {
                o += "Private DNS: ${if (lp.isPrivateDnsActive) "aktif (${lp.privateDnsServerName ?: "otomatis"})" else "mati"}"
            }
            val hasV6 = lp.linkAddresses.any { it.address is java.net.Inet6Address && !it.address.isLinkLocalAddress }
            o += "IPv6 global: ${if (hasV6) "ya" else "tidak"}"
            if (Build.VERSION.SDK_INT >= 29) {
                lp.routes.forEach { r -> o += "Rute: ${r.destination}${r.gateway?.let { " via ${it.hostAddress}" } ?: ""}" }
            }
        }

        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION") val wi = wm.connectionInfo
            o += ""; o += "== WI-FI =="
            o += "SSID: ${wi.ssid?.trim('"')}${if (wi.hiddenSSID) " (tersembunyi)" else ""}"
            o += "BSSID: ${wi.bssid}"
            o += "Sinyal: ${wi.rssi} dBm (${signalLabel(wi.rssi)})"
            o += "Link speed: ${wi.linkSpeed} Mbps"
            if (Build.VERSION.SDK_INT >= 29) {
                o += "Link speed RX/TX: ${wi.rxLinkSpeedMbps} / ${wi.txLinkSpeedMbps} Mbps"
                o += "Maks didukung TX/RX: ${wi.maxSupportedTxLinkSpeedMbps} / ${wi.maxSupportedRxLinkSpeedMbps} Mbps"
            }
            o += "Frekuensi: ${wi.frequency} MHz (${band(wi.frequency)}, kanal ${channel(wi.frequency)})"
            if (Build.VERSION.SDK_INT >= 30) o += "Standar: ${wifiStd(wi.wifiStandard)}"
            if (wi.ssid == "<unknown ssid>") o += "(SSID tidak terbaca? Izinkan akses lokasi dan aktifkan layanan lokasi.)"

            val ap = try { wm.scanResults.firstOrNull { it.BSSID == wi.bssid } } catch (e: SecurityException) { null }
            if (ap != null) {
                o += "Lebar kanal: ${widthName(ap.channelWidth)}"
                o += "Keamanan: ${ap.capabilities}"
                if (Build.VERSION.SDK_INT >= 30) o += "Standar AP: ${wifiStd(ap.wifiStandard)}"
            }

            @Suppress("DEPRECATION") val dh = wm.dhcpInfo
            if (dh != null) {
                o += ""; o += "== DHCP =="
                o += "IP: ${ipStr(dh.ipAddress)}   Netmask: ${ipStr(dh.netmask)}"
                o += "Gateway: ${ipStr(dh.gateway)}   Server DHCP: ${ipStr(dh.serverAddress)}"
                o += "DNS 1/2: ${ipStr(dh.dns1)} / ${ipStr(dh.dns2)}"
                o += "Lease: ${dh.leaseDuration} detik"
            }
        }

        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            o += ""; o += "== SELULER (ringkas, detail di tab Seluler) =="
            o += "Operator: ${tm.networkOperatorName} (${tm.networkOperator})"
            o += "Roaming: ${tm.isNetworkRoaming}"
            val t = try { cellType(tm.dataNetworkType) } catch (e: SecurityException) { "butuh izin Phone State" }
            o += "Jenis jaringan: $t"
        }

        o += ""; o += "== ANTARMUKA JARINGAN =="
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.filter { it.isUp && !it.isLoopback }?.forEach { ni ->
                val mac = try {
                    ni.hardwareAddress?.joinToString(":") { String.format("%02X", it) }
                } catch (e: Exception) { null }
                o += "${ni.name}  MTU ${ni.mtu}${if (ni.isVirtual) "  (virtual)" else ""}${if (mac != null) "  MAC $mac" else ""}"
                ni.interfaceAddresses.forEach { ia ->
                    o += "   ${ia.address.hostAddress?.substringBefore('%')}/${ia.networkPrefixLength}"
                }
            }
        } catch (e: Exception) {
            o += "(tidak dapat membaca antarmuka)"
        }
        o += "(Catatan: MAC Wi-Fi biasanya acak demi privasi sejak Android 10, bukan MAC fisik asli.)"

        val upMs = SystemClock.elapsedRealtime()
        val upH = upMs / 3_600_000
        val upM = (upMs / 60_000) % 60
        o += ""; o += "Uptime perangkat: ${upH}j ${upM}m (sejak boot terakhir)"

        o += ""; o += "== SEMUA JARINGAN YANG TERSEDIA =="
        @Suppress("DEPRECATION")
        cm.allNetworks.forEach { n ->
            val c = cm.getNetworkCapabilities(n)
            val l = cm.getLinkProperties(n)
            o += "${l?.interfaceName ?: "?"}  ${transportsOf(c)}  validated=${c?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)}${if (n == net) "  <- aktif" else ""}"
        }
        return o
    }

    // ---------------------------------------------------------------- seluler

    private fun u(x: Int) = if (x == Int.MAX_VALUE || x == Int.MIN_VALUE) "-" else x.toString()
    private fun uL(x: Long) = if (x == Long.MAX_VALUE) "-" else x.toString()

    fun rsrpLabel(v: Int) = when {
        v == Int.MAX_VALUE -> "-"
        v >= -80 -> "sangat baik"
        v >= -90 -> "baik"
        v >= -100 -> "cukup"
        v >= -110 -> "lemah"
        else -> "sangat lemah"
    }

    private fun lteBand(e: Int) = when (e) {
        in 0..599 -> "B1"; in 600..1199 -> "B2"; in 1200..1949 -> "B3"; in 1950..2399 -> "B4"
        in 2400..2649 -> "B5"; in 2750..3449 -> "B7"; in 3450..3799 -> "B8"; in 6150..6449 -> "B20"
        in 9210..9659 -> "B28"; in 37750..38249 -> "B38"; in 38650..39649 -> "B40"; in 39650..41589 -> "B41"
        else -> "?"
    }

    private fun simState(s: Int) = when (s) {
        1 -> "tidak ada SIM"; 2 -> "terkunci PIN"; 3 -> "terkunci PUK"; 4 -> "terkunci jaringan"
        5 -> "siap"; 6 -> "belum siap"; 7 -> "dinonaktifkan"; 8 -> "kartu error"; 9 -> "dibatasi"; else -> "tidak diketahui"
    }

    private fun dataState(s: Int) = when (s) {
        0 -> "terputus"; 1 -> "menghubungkan"; 2 -> "terhubung"; 3 -> "ditangguhkan"; else -> "?"
    }

    @SuppressLint("NewApi")
    private fun cellLines(c: CellInfo): List<String> {
        val l = mutableListOf<String>()
        val tag = if (c.isRegistered) "[TERHUBUNG]" else "[tetangga]"
        when {
            c is CellInfoLte -> {
                val id = c.cellIdentity
                val s = c.cellSignalStrength
                val band = if (Build.VERSION.SDK_INT >= 30 && id.bands.isNotEmpty()) "B" + id.bands.joinToString("/") else lteBand(id.earfcn)
                l += "$tag LTE (4G)"
                l += "   Cell ID ${u(id.ci)}  PCI ${u(id.pci)}  TAC ${u(id.tac)}  EARFCN ${u(id.earfcn)}  Band $band"
                if (Build.VERSION.SDK_INT >= 28) l += "   MCC-MNC ${id.mccString}-${id.mncString}  Lebar ${u(id.bandwidth)} kHz"
                l += "   RSRP ${u(s.rsrp)} dBm (${rsrpLabel(s.rsrp)})  RSRQ ${u(s.rsrq)} dB  SINR ${u(s.rssnr)} dB"
                l += "   CQI ${u(s.cqi)}  Timing Advance ${u(s.timingAdvance)}  Level ${s.level}/4"
            }
            Build.VERSION.SDK_INT >= 29 && c is CellInfoNr -> {
                val id = c.cellIdentity as CellIdentityNr
                val s = c.cellSignalStrength as CellSignalStrengthNr
                val band = if (Build.VERSION.SDK_INT >= 30 && id.bands.isNotEmpty()) "n" + id.bands.joinToString("/") else "?"
                l += "$tag 5G NR"
                l += "   NCI ${uL(id.nci)}  PCI ${u(id.pci)}  TAC ${u(id.tac)}  NRARFCN ${u(id.nrarfcn)}  Band $band"
                l += "   MCC-MNC ${id.mccString}-${id.mncString}"
                l += "   SS-RSRP ${u(s.ssRsrp)} dBm (${rsrpLabel(s.ssRsrp)})  SS-RSRQ ${u(s.ssRsrq)} dB  SS-SINR ${u(s.ssSinr)} dB"
                l += "   CSI-RSRP ${u(s.csiRsrp)} dBm  CSI-RSRQ ${u(s.csiRsrq)} dB  CSI-SINR ${u(s.csiSinr)} dB  Level ${s.level}/4"
            }
            c is CellInfoWcdma -> {
                val id = c.cellIdentity
                val s = c.cellSignalStrength
                l += "$tag WCDMA (3G)"
                l += "   Cell ID ${u(id.cid)}  LAC ${u(id.lac)}  PSC ${u(id.psc)}  UARFCN ${u(id.uarfcn)}"
                l += "   Sinyal ${u(s.dbm)} dBm  Level ${s.level}/4"
            }
            c is CellInfoGsm -> {
                val id = c.cellIdentity
                val s = c.cellSignalStrength
                l += "$tag GSM (2G)"
                l += "   Cell ID ${u(id.cid)}  LAC ${u(id.lac)}  ARFCN ${u(id.arfcn)}  BSIC ${u(id.bsic)}"
                l += "   Sinyal ${u(s.dbm)} dBm  Level ${s.level}/4"
            }
            else -> l += "$tag ${c.javaClass.simpleName}"
        }
        return l
    }

    @SuppressLint("MissingPermission", "NewApi")
    fun cellular(ctx: Context): List<String> {
        val o = mutableListOf<String>()
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        if (tm == null || tm.phoneType == TelephonyManager.PHONE_TYPE_NONE) {
            o += "Perangkat ini tidak memiliki modem seluler."
            return o
        }
        o += "== SIM & OPERATOR =="
        o += "Operator jaringan: ${tm.networkOperatorName} (${tm.networkOperator})"
        o += "Operator SIM: ${tm.simOperatorName} (${tm.simOperator}), negara ${tm.simCountryIso?.uppercase()}"
        o += "Status SIM: ${simState(tm.simState)}"
        o += "Roaming: ${tm.isNetworkRoaming}"
        val t = try { cellType(tm.dataNetworkType) } catch (e: SecurityException) { "butuh izin Phone State" }
        o += "Jenis jaringan data: $t"
        o += "Status data: ${dataState(tm.dataState)}"
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                tm.signalStrength?.cellSignalStrengths?.forEach { s ->
                    o += "Sinyal ${s.javaClass.simpleName.removePrefix("CellSignalStrength")}: ${s.dbm} dBm, level ${s.level}/4"
                }
            } catch (e: SecurityException) {
            }
        }
        o += ""; o += "== INFO SEL (BTS) =="
        val cells = try { tm.allCellInfo } catch (e: SecurityException) { null }
        if (cells.isNullOrEmpty()) {
            o += "Tidak ada info sel. Pastikan izin Lokasi + Phone State diberikan dan layanan lokasi aktif."
        } else {
            cells.forEach { o += cellLines(it) }
            o += ""
            o += "Panduan RSRP: >= -80 sangat baik, -90 baik, -100 cukup, -110 lemah, di bawahnya sangat lemah."
            o += "SINR: >= 20 sangat baik, 13-20 baik, 0-13 cukup, di bawah 0 buruk."
        }
        return o
    }

    private fun bar(v: Int, lo: Int, hi: Int): String {
        val n = ((v - lo).coerceIn(0, hi - lo) * 10) / (hi - lo)
        return "█".repeat(n) + "░".repeat(10 - n)
    }

    @SuppressLint("MissingPermission", "NewApi")
    suspend fun liveSignal(ctx: Context, out: Out) = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val tm = ctx.getSystemService(TelephonyManager::class.java)
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        out("Memantau sinyal tiap 1 detik (tekan Stop untuk berhenti).")
        out("Berjalanlah di sekitar untuk mencari titik sinyal terbaik.")
        out("")
        while (isActive) {
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val now = fmt.format(Date())
            when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> {
                    @Suppress("DEPRECATION") val wi = wm.connectionInfo
                    out("$now  WiFi ${bar(wi.rssi, -90, -30)} ${wi.rssi} dBm  ${wi.linkSpeed} Mbps  ${band(wi.frequency)} ch${channel(wi.frequency)}")
                }
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> {
                    val s = try {
                        if (Build.VERSION.SDK_INT >= 28) tm.signalStrength?.cellSignalStrengths?.firstOrNull() else null
                    } catch (e: SecurityException) { null }
                    if (s != null) {
                        out("$now  ${s.javaClass.simpleName.removePrefix("CellSignalStrength")} ${bar(s.dbm, -120, -70)} ${s.dbm} dBm  level ${s.level}/4")
                    } else {
                        out("$now  Seluler (sinyal tidak terbaca, cek izin Phone State)")
                    }
                }
                else -> out("$now  Tidak ada koneksi Wi-Fi/seluler")
            }
            delay(1000)
        }
    }

    suspend fun ipVersions(): List<String> = withContext(Dispatchers.IO) {
        fun get(u: String): String? = try {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 4000
            c.readTimeout = 4000
            val t = c.inputStream.bufferedReader().readText().trim()
            c.disconnect()
            t
        } catch (e: Exception) { null }
        val v4 = get("https://api.ipify.org")
        val v6 = get("https://api6.ipify.org")
        listOf(
            "IPv4 publik: ${v4 ?: "tidak tersedia"}",
            "IPv6 publik: ${v6 ?: "tidak tersedia (jaringan hanya IPv4)"}"
        )
    }

    suspend fun publicIp(): List<String> = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://ipwho.is/").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            c.disconnect()
            if (!j.optBoolean("success", true)) return@withContext listOf("Gagal: ${j.optString("message")}")
            val conn = j.optJSONObject("connection")
            listOf(
                "IP publik: ${j.optString("ip")} (${j.optString("type")})",
                "Lokasi (perkiraan): ${j.optString("city")}, ${j.optString("region")}, ${j.optString("country")}",
                "ISP: ${conn?.optString("isp")}",
                "Organisasi: ${conn?.optString("org")}",
                "ASN: AS${conn?.optInt("asn")}",
                "Zona waktu: ${j.optJSONObject("timezone")?.optString("id")}"
            )
        } catch (e: Exception) {
            listOf("Tidak bisa mengambil IP publik (${e.javaClass.simpleName})")
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun wifiScan(ctx: Context, out: Out) = withContext(Dispatchers.IO) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) { out("Wi-Fi mati. Aktifkan Wi-Fi terlebih dahulu."); return@withContext }
        @Suppress("DEPRECATION")
        val started = try { wm.startScan() } catch (e: SecurityException) { false }
        out(if (started) "Memindai jaringan Wi-Fi..." else "Scan dibatasi OS (throttle), menampilkan hasil terakhir...")
        delay(3500)
        val res = try { wm.scanResults } catch (e: SecurityException) {
            out("Izin lokasi diperlukan untuk memindai Wi-Fi."); return@withContext
        }
        if (res.isEmpty()) { out("Tidak ada hasil. Pastikan izin lokasi & layanan lokasi aktif."); return@withContext }
        out("Ditemukan ${res.size} jaringan:\n")
        res.sortedByDescending { it.level }.forEach { r ->
            @Suppress("DEPRECATION") val name = r.SSID.ifEmpty { "(tersembunyi)" }
            val cap = r.capabilities
            val sec = when {
                cap.contains("WPA3") || cap.contains("SAE") -> "WPA3"
                cap.contains("WPA2") -> "WPA2"
                cap.contains("WPA") -> "WPA"
                cap.contains("WEP") -> "WEP"
                else -> "Terbuka"
            }
            out("$name")
            out("   ${r.BSSID}  ${r.level} dBm (${signalLabel(r.level)})")
            out("   ${band(r.frequency)}  kanal ${channel(r.frequency)}  $sec")
        }
        val ch = res.filter { it.frequency < 3000 }.groupingBy { channel(it.frequency) }.eachCount()
        out(""); out("== Kepadatan kanal 2.4 GHz ==")
        for (c in 1..13) out("Kanal ${c.toString().padStart(2)}: ${"█".repeat(ch[c] ?: 0)} ${ch[c] ?: 0}")
        val best = listOf(1, 6, 11).minByOrNull { ch[it] ?: 0 }
        out("Saran kanal 2.4 GHz paling lengang: $best")
    }
}
