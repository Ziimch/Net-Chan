package com.netlab.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object NetInfo {

    fun signalLabel(dbm: Int) = when {
        dbm >= -50 -> "sangat baik"
        dbm >= -60 -> "baik"
        dbm >= -70 -> "cukup"
        dbm >= -80 -> "lemah"
        else -> "sangat lemah"
    }

    fun band(f: Int) = when { f < 3000 -> "2.4 GHz"; f < 5925 -> "5 GHz"; else -> "6 GHz" }
    fun channel(f: Int) = when { f == 2484 -> 14; f < 3000 -> (f - 2407) / 5; f < 5925 -> (f - 5000) / 5; else -> (f - 5950) / 5 }

    private fun wifiStd(s: Int) = when (s) {
        4 -> "Wi-Fi 4 (802.11n)"; 5 -> "Wi-Fi 5 (802.11ac)"; 6 -> "Wi-Fi 6 (802.11ax)"
        8 -> "Wi-Fi 7 (802.11be)"; else -> "Legacy / tidak diketahui"
    }

    private fun cellType(t: Int) = when (t) {
        20 -> "5G NR"; 13 -> "4G LTE"; 15, 10, 9, 8, 3 -> "3G (HSPA/UMTS)"; 2, 1 -> "2G (EDGE/GPRS)"
        else -> "tidak diketahui ($t)"
    }

    @SuppressLint("MissingPermission")
    fun local(ctx: Context): List<String> {
        val o = mutableListOf<String>()
        o += "Perangkat: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT})"
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork
        if (net == null) { o += "Tidak ada koneksi aktif."; return o }
        val caps = cm.getNetworkCapabilities(net)
        val lp = cm.getLinkProperties(net)

        o += ""; o += "== KONEKSI =="
        val tr = mutableListOf<String>()
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) tr += "Wi-Fi"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) tr += "Seluler"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true) tr += "Ethernet"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) tr += "VPN"
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) == true) tr += "Bluetooth"
        o += "Tipe: ${tr.joinToString(" + ").ifEmpty { "tidak diketahui" }}"
        if (caps != null) {
            o += "Internet tervalidasi: ${caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)}"
            o += "Berbayar/metered: ${!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)}"
            o += "Estimasi OS (turun/naik): ${caps.linkDownstreamBandwidthKbps / 1000} / ${caps.linkUpstreamBandwidthKbps / 1000} Mbps"
        }

        if (lp != null) {
            o += ""; o += "== IP & ROUTING =="
            o += "Interface: ${lp.interfaceName}"
            lp.linkAddresses.forEach { o += "Alamat: ${it.address.hostAddress}/${it.prefixLength}" }
            val gws = lp.routes.filter { it.isDefaultRoute }.mapNotNull { it.gateway?.hostAddress }.distinct()
            o += "Gateway: ${gws.joinToString().ifEmpty { "-" }}"
            o += "DNS: ${lp.dnsServers.joinToString { it.hostAddress ?: "" }.ifEmpty { "-" }}"
            if (!lp.domains.isNullOrEmpty()) o += "Domain: ${lp.domains}"
            if (Build.VERSION.SDK_INT >= 29) o += "MTU: ${lp.mtu}"
            if (Build.VERSION.SDK_INT >= 28) {
                o += "Private DNS: ${if (lp.isPrivateDnsActive) "aktif (${lp.privateDnsServerName ?: "otomatis"})" else "mati"}"
            }
        }

        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION") val wi = wm.connectionInfo
            o += ""; o += "== WI-FI =="
            o += "SSID: ${wi.ssid?.trim('"')}"
            o += "BSSID: ${wi.bssid}"
            o += "Sinyal: ${wi.rssi} dBm (${signalLabel(wi.rssi)})"
            o += "Link speed: ${wi.linkSpeed} Mbps"
            if (Build.VERSION.SDK_INT >= 29) o += "Link speed RX/TX: ${wi.rxLinkSpeedMbps} / ${wi.txLinkSpeedMbps} Mbps"
            o += "Frekuensi: ${wi.frequency} MHz (${band(wi.frequency)}, kanal ${channel(wi.frequency)})"
            if (Build.VERSION.SDK_INT >= 30) o += "Standar: ${wifiStd(wi.wifiStandard)}"
            if (wi.ssid == "<unknown ssid>") o += "(SSID tersembunyi? Izinkan akses lokasi agar SSID terbaca.)"
        }

        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true) {
            val tm = ctx.getSystemService(TelephonyManager::class.java)
            o += ""; o += "== SELULER =="
            o += "Operator: ${tm.networkOperatorName}"
            o += "Kode MCC-MNC: ${tm.networkOperator}"
            o += "Roaming: ${tm.isNetworkRoaming}"
            val t = try { cellType(tm.dataNetworkType) } catch (e: SecurityException) { "butuh izin Phone State" }
            o += "Jenis jaringan: $t"
        }
        return o
    }

    suspend fun publicIp(): List<String> = withContext(Dispatchers.IO) {
        try {
            val c = URL("https://ipwho.is/").openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 5000
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            c.disconnect()
            if (!j.optBoolean("success", true)) return@withContext listOf("Gagal: ${j.optString("message")}")
            val conn = j.optJSONObject("connection")
            listOf(
                "IP publik: ${j.optString("ip")} (${j.optString("type")})",
                "Lokasi (perkiraan): ${j.optString("city")}, ${j.optString("region")}, ${j.optString("country")}",
                "ISP: ${conn?.optString("isp")}",
                "Organisasi: ${conn?.optString("org")}",
                "ASN: AS${conn?.optInt("asn")}",
                "Zona waktu: ${j.optJSONObject("timezone")?.optString("id")}"
            )
        } catch (e: Exception) {
            listOf("Tidak bisa mengambil IP publik (${e.javaClass.simpleName})")
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun wifiScan(ctx: Context, out: Out) = withContext(Dispatchers.IO) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wm.isWifiEnabled) { out("Wi-Fi mati. Aktifkan Wi-Fi terlebih dahulu."); return@withContext }
        @Suppress("DEPRECATION")
        val started = try { wm.startScan() } catch (e: SecurityException) { false }
        out(if (started) "Memindai jaringan Wi-Fi..." else "Scan dibatasi OS (throttle), menampilkan hasil terakhir...")
        delay(3500)
        val res = try { wm.scanResults } catch (e: SecurityException) {
            out("Izin lokasi diperlukan untuk memindai Wi-Fi."); return@withContext
        }
        if (res.isEmpty()) { out("Tidak ada hasil. Pastikan izin lokasi & layanan lokasi aktif."); return@withContext }
        out("Ditemukan ${res.size} jaringan:\n")
        res.sortedByDescending { it.level }.forEach { r ->
            @Suppress("DEPRECATION") val name = r.SSID.ifEmpty { "(tersembunyi)" }
            val cap = r.capabilities
            val sec = when {
                cap.contains("WPA3") || cap.contains("SAE") -> "WPA3"
                cap.contains("WPA2") -> "WPA2"
                cap.contains("WPA") -> "WPA"
                cap.contains("WEP") -> "WEP"
                else -> "Terbuka"
            }
            out("$name")
            out("   ${r.BSSID}  ${r.level} dBm (${signalLabel(r.level)})")
            out("   ${band(r.frequency)}  kanal ${channel(r.frequency)}  $sec")
        }
        val ch = res.filter { it.frequency < 3000 }.groupingBy { channel(it.frequency) }.eachCount()
        out(""); out("== Kepadatan kanal 2.4 GHz ==")
        for (c in 1..13) out("Kanal ${c.toString().padStart(2)}: ${"█".repeat(ch[c] ?: 0)} ${ch[c] ?: 0}")
        val best = listOf(1, 6, 11).minByOrNull { ch[it] ?: 0 }
        out("Saran kanal 2.4 GHz paling lengang: $best")
    }
}
