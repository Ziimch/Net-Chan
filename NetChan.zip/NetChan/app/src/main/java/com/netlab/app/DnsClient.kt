package com.netlab.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.IDN
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.Locale
import java.util.Random

class BenchRow(val name: String, val avg: Double, val min: Double, val fail: Int)

/** Klien DNS mentah (UDP/53) supaya bisa bertanya langsung ke server DNS tertentu. */
object DnsClient {

    val TYPES = linkedMapOf("A" to 1, "AAAA" to 28, "MX" to 15, "NS" to 2, "TXT" to 16, "CNAME" to 5, "SOA" to 6)
    private val typeNames = TYPES.entries.associate { it.value to it.key }

    class Reply(val rcode: Int, val answers: List<String>, val ms: Double, val flags: Int) {
        val truncated: Boolean get() = (flags and 0x0200) != 0
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or
            ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    private fun buildQuery(name: String, type: Int, id: Int): ByteArray {
        val b = ByteArrayOutputStream()
        b.write(id shr 8); b.write(id and 0xFF)
        b.write(0x01); b.write(0x00)                 // flags: RD
        b.write(0); b.write(1)                       // QDCOUNT
        for (i in 0 until 6) b.write(0)              // AN/NS/AR = 0
        for (label in name.trimEnd('.').split('.')) {
            val bytes = label.toByteArray(Charsets.US_ASCII)
            b.write(bytes.size); b.write(bytes)
        }
        b.write(0)
        b.write(type shr 8); b.write(type and 0xFF)
        b.write(0); b.write(1)                       // class IN
        return b.toByteArray()
    }

    private fun readName(buf: ByteArray, start: Int): Pair<String, Int> {
        val sb = StringBuilder()
        var pos = start
        var end = -1
        var hops = 0
        while (pos < buf.size) {
            val len = buf[pos].toInt() and 0xFF
            if (len == 0) { pos++; break }
            if ((len and 0xC0) == 0xC0) {
                val ptr = ((len and 0x3F) shl 8) or (buf[pos + 1].toInt() and 0xFF)
                if (end < 0) end = pos + 2
                pos = ptr
                hops++
                if (hops > 20) break
                continue
            }
            sb.append(String(buf, pos + 1, len, Charsets.US_ASCII)).append('.')
            pos += 1 + len
        }
        return Pair(if (sb.isEmpty()) "." else sb.toString(), if (end >= 0) end else pos)
    }

    private fun txt(b: ByteArray, start: Int, len: Int): String {
        val sb = StringBuilder()
        var p = start
        while (p < start + len) {
            val l = b[p].toInt() and 0xFF
            sb.append(String(b, p + 1, l, Charsets.UTF_8))
            p += 1 + l
        }
        return "\"$sb\""
    }

    private fun parse(b: ByteArray, ms: Double): Reply {
        val flags = u16(b, 2)
        val rcode = flags and 0x0F
        val qd = u16(b, 4)
        val an = u16(b, 6)
        var pos = 12
        for (i in 0 until qd) pos = readName(b, pos).second + 4
        val out = ArrayList<String>()
        for (i in 0 until an) {
            val (nm, p1) = readName(b, pos)
            val type = u16(b, p1)
            val ttl = u32(b, p1 + 4)
            val rdlen = u16(b, p1 + 8)
            val rd = p1 + 10
            val data: String = when (type) {
                1 -> if (rdlen == 4) InetAddress.getByAddress(b.copyOfRange(rd, rd + 4)).hostAddress ?: "?" else "?"
                28 -> if (rdlen == 16) InetAddress.getByAddress(b.copyOfRange(rd, rd + 16)).hostAddress ?: "?" else "?"
                2, 5 -> readName(b, rd).first
                15 -> "prioritas ${u16(b, rd)}  ${readName(b, rd + 2).first}"
                16 -> txt(b, rd, rdlen)
                6 -> {
                    val (mn, p2) = readName(b, rd)
                    val (rn, p3) = readName(b, p2)
                    "$mn  $rn  serial=${u32(b, p3)}"
                }
                else -> "(tipe $type, $rdlen byte)"
            }
            out.add("${typeNames[type] ?: type.toString()}  $nm  ->  $data  (TTL ${ttl}s)")
            pos = rd + rdlen
        }
        return Reply(rcode, out, ms, flags)
    }

    fun query(server: String, name: String, type: Int, timeoutMs: Int = 3000): Reply {
        val q = buildQuery(IDN.toASCII(name), type, Random().nextInt(65536))
        val addr = InetAddress.getByName(server)
        val t0 = System.nanoTime()
        return DatagramSocket().use { s ->
            s.soTimeout = timeoutMs
            s.send(DatagramPacket(q, q.size, addr, 53))
            val buf = ByteArray(4096)
            val p = DatagramPacket(buf, buf.size)
            s.receive(p)
            val ms = (System.nanoTime() - t0) / 1e6
            parse(buf.copyOf(p.length), ms)
        }
    }

    private fun rcodeName(r: Int) = when (r) {
        0 -> "NOERROR (berhasil)"; 1 -> "FORMERR"; 2 -> "SERVFAIL (server gagal)"
        3 -> "NXDOMAIN (domain tidak ada)"; 4 -> "NOTIMP"; 5 -> "REFUSED (ditolak)"; else -> "RCODE $r"
    }

    private fun flagText(f: Int): String {
        val l = ArrayList<String>()
        if ((f and 0x8000) != 0) l.add("QR")
        if ((f and 0x0400) != 0) l.add("AA (otoritatif)")
        if ((f and 0x0200) != 0) l.add("TC (terpotong)")
        if ((f and 0x0100) != 0) l.add("RD")
        if ((f and 0x0080) != 0) l.add("RA (rekursif tersedia)")
        if ((f and 0x0020) != 0) l.add("AD (DNSSEC tervalidasi)")
        return l.joinToString(", ")
    }

    suspend fun lookup(server: String, name: String, typeName: String, out: Out) = withContext(Dispatchers.IO) {
        val type = TYPES[typeName] ?: 1
        out("Query: $name  tipe $typeName  ->  server $server")
        try {
            val r = query(server, name, type)
            out("Status: ${rcodeName(r.rcode)}")
            out("Waktu : ${f1(r.ms)} ms")
            out("Flag  : ${flagText(r.flags)}")
            if (r.truncated) out("(Respons terpotong, hasil mungkin tidak lengkap)")
            out("")
            if (r.answers.isEmpty()) out("Tidak ada jawaban.") else r.answers.forEach { out(it) }
        } catch (e: SocketTimeoutException) {
            out("Timeout: server $server tidak membalas (UDP port 53 mungkin diblokir jaringan).")
        } catch (e: Exception) {
            out("Gagal: ${e.javaClass.simpleName}: ${e.message}")
        }
    }

    suspend fun benchmark(current: List<String>, out: Out) = withContext(Dispatchers.IO) {
        val servers = ArrayList<Pair<String, String>>()
        current.forEach { servers.add("DNS jaringan ($it)" to it) }
        servers.addAll(
            listOf(
                "Google" to "8.8.8.8", "Google 2" to "8.8.4.4", "Cloudflare" to "1.1.1.1",
                "Quad9" to "9.9.9.9", "OpenDNS" to "208.67.222.222", "AdGuard" to "94.140.14.14"
            )
        )
        val domains = listOf("google.com", "youtube.com", "facebook.com", "wikipedia.org", "tokopedia.com", "detik.com")
        out("Benchmark DNS: ${servers.size} server x ${domains.size} domain x 2 putaran")
        out("(min = mendekati latensi jaringan ke server DNS)")
        out("")
        val rows = ArrayList<BenchRow>()
        for ((name, ip) in servers) {
            ensureActive()
            val t = ArrayList<Double>()
            var fail = 0
            for (round in 0 until 2) {
                for (d in domains) {
                    try {
                        val r = query(ip, d, 1, 2000)
                        if (r.rcode == 0) t.add(r.ms) else fail++
                    } catch (e: Exception) { fail++ }
                }
            }
            if (t.isEmpty()) {
                out(String.format(Locale.US, "%-30s tidak merespons", name))
            } else {
                rows.add(BenchRow(name, t.average(), t.min(), fail))
                out(String.format(Locale.US, "%-30s rata2 %6s ms   min %6s ms   gagal %d", name, f1(t.average()), f1(t.min()), fail))
            }
        }
        out("")
        val sorted = rows.sortedBy { it.avg }
        if (sorted.isNotEmpty()) {
            out("Peringkat tercepat:")
            sorted.forEachIndexed { i, r -> out("${i + 1}. ${r.name}  (${f1(r.avg)} ms)") }
            out("")
            out("Tercepat: ${sorted.first().name}. Untuk mengganti DNS: Pengaturan > Jaringan > DNS Pribadi.")
        }
    }
}
