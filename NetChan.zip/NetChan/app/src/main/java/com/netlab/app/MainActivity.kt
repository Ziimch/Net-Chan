package com.netlab.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
            .launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE))
        setContent {
            MaterialTheme(colorScheme = NetChanColors) {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(R.drawable.bg_umbrella),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(Modifier.fillMaxSize().background(Color(0x59081426)))
                    Surface(
                        Modifier.fillMaxSize(),
                        color = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onBackground
                    ) { App() }
                }
            }
        }
    }
}

private val NetChanColors = darkColorScheme(
    primary = Color(0xFF9CC3FF),
    onPrimary = Color(0xFF0A1B3A),
    secondary = Color(0xFFB9C8E8),
    background = Color(0xFF16284A),
    onBackground = Color(0xFFE8EEFA),
    surface = Color(0xFF1B2F55),
    onSurface = Color(0xFFE8EEFA),
    surfaceVariant = Color(0xFF263E6B),
    onSurfaceVariant = Color(0xFFC3D2EE),
    outline = Color(0xFF8FA6CF)
)

/** Menjalankan tugas jaringan dan menampung log keluaran. */
class Runner(private val scope: CoroutineScope) {
    var running by mutableStateOf(false)
        private set
    val log = mutableStateListOf<String>()
    private var job: Job? = null

    fun add(s: String) {
        scope.launch(Dispatchers.Main) {
            log.add(s)
            if (log.size > 600) log.removeAt(0)
        }
    }

    fun start(block: suspend () -> Unit) {
        if (running) return
        log.clear()
        running = true
        job = scope.launch {
            try { block() }
            catch (e: CancellationException) { add("-- dihentikan --"); throw e }
            catch (e: Exception) { add("Error: ${e.message}") }
            finally { running = false }
        }
    }

    fun stop() { job?.cancel() }
}

@Composable
fun rememberRunner(): Runner {
    val scope = rememberCoroutineScope()
    return remember { Runner(scope) }
}

@Composable
fun LogBox(lines: List<String>, modifier: Modifier) {
    val sc = rememberScrollState()
    LaunchedEffect(lines.size) { sc.animateScrollTo(sc.maxValue) }
    Surface(
        modifier,
        color = Color(0xB30B1730),
        contentColor = Color(0xFFE8EEFA),
        shape = RoundedCornerShape(12.dp)
    ) {
        SelectionContainer {
            Text(
                lines.joinToString("\n"),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().verticalScroll(sc).padding(8.dp)
            )
        }
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0x800B1730),
            unfocusedContainerColor = Color(0x800B1730)
        )
    )
}

@Composable
fun ToolLayout(
    r: Runner,
    runLabel: String,
    onRun: () -> Unit,
    inputs: @Composable ColumnScope.() -> Unit = {}
) {
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        inputs()
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onRun, enabled = !r.running) { Text(runLabel) }
            OutlinedButton(onClick = { r.stop() }, enabled = r.running) { Text("Stop") }
            OutlinedButton(onClick = { clip.setText(AnnotatedString(r.log.joinToString("\n"))) }) { Text("Salin") }
        }
        Spacer(Modifier.height(8.dp))
        LogBox(r.log, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
fun App() {
    val tabs = listOf("Info", "Ping", "Traceroute", "Speed Test", "DNS", "Port Scan", "LAN Scan", "Wi-Fi", "Cek Layanan", "Monitor")
    var sel by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Text("Net-Chan - Network Toolkit", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(12.dp))
        ScrollableTabRow(
            selectedTabIndex = sel,
            edgePadding = 8.dp,
            containerColor = Color(0x990B1730),
            contentColor = Color(0xFF9CC3FF)
        ) {
            tabs.forEachIndexed { i, t -> Tab(
                    selected = sel == i, onClick = { sel = i }, text = { Text(t) },
                    unselectedContentColor = Color(0xFFC3D2EE)
                ) }
        }
        when (sel) {
            0 -> InfoTab()
            1 -> PingTab()
            2 -> TraceTab()
            3 -> SpeedTab()
            4 -> DnsTab()
            5 -> PortTab()
            6 -> LanTab()
            7 -> WifiTab()
            8 -> ServiceTab()
            9 -> MonitorTab()
        }
    }
}

@Composable
fun InfoTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    val run = {
        r.start {
            r.add("== PERANGKAT ==")
            NetInfo.local(ctx).forEach { r.add(it) }
            r.add(""); r.add("== IP PUBLIK ==")
            NetInfo.publicIp().forEach { r.add(it) }
        }
    }
    LaunchedEffect(Unit) { run() }
    ToolLayout(r, "Muat ulang", run)
}

@Composable
fun PingTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("8.8.8.8") }
    var count by rememberSaveable { mutableStateOf("10") }
    ToolLayout(r, "Mulai Ping", {
        r.start { NetTools.ping(host.trim(), (count.toIntOrNull() ?: 10).coerceIn(1, 100)) { r.add(it) } }
    }) {
        Field(host, { host = it }, "Host / IP")
        Field(count, { count = it }, "Jumlah paket (1-100)")
    }
}

@Composable
fun TraceTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("google.com") }
    ToolLayout(r, "Mulai Traceroute", {
        r.start { NetTools.trace(host.trim(), 30) { r.add(it) } }
    }) { Field(host, { host = it }, "Host / IP tujuan") }
}

@Composable
fun SpeedTab() {
    val r = rememberRunner()
    ToolLayout(r, "Mulai Speed Test", { r.start { NetTools.speedTest { r.add(it) } } }) {
        Text("Mengukur latensi, jitter, download, dan upload memakai server Cloudflare. Menggunakan kuota data.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
fun DnsTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("google.com") }
    ToolLayout(r, "Lookup", { r.start { NetTools.dns(host.trim()) { r.add(it) } } }) {
        Field(host, { host = it }, "Domain / IP")
    }
}

@Composable
fun PortTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("scanme.nmap.org") }
    var ports by rememberSaveable { mutableStateOf("common") }
    ToolLayout(r, "Mulai Scan", {
        r.start { NetTools.portScan(host.trim(), NetTools.parsePorts(ports)) { r.add(it) } }
    }) {
        Field(host, { host = it }, "Host / IP")
        Field(ports, { ports = it }, "Port (common, atau 22,80,443 atau 1-1024)")
        Text("Hanya pindai perangkat/server milik sendiri atau yang Anda punya izin.",
            style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
fun LanTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(r, "Pindai LAN", { r.start { NetTools.lanScan(ctx) { r.add(it) } } })
}

@Composable
fun WifiTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(r, "Pindai Wi-Fi", { r.start { NetInfo.wifiScan(ctx) { r.add(it) } } })
}

@Composable
fun ServiceTab() {
    val r = rememberRunner()
    ToolLayout(r, "Cek Layanan", { r.start { NetTools.httpCheck(NetTools.DEFAULT_SITES) { r.add(it) } } })
}

@Composable
fun MonitorTab() {
    val r = rememberRunner()
    ToolLayout(r, "Mulai Monitor", { r.start { NetTools.monitor { r.add(it) } } })
}
