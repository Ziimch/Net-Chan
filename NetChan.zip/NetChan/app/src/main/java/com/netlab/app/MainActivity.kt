package com.netlab.app

import android.Manifest
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
            .launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_PHONE_STATE))
        setContent {
            MaterialTheme(colorScheme = NetChanColors, typography = NetChanType) {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(R.drawable.bg_umbrella),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(Modifier.fillMaxSize().background(Brush.vert()))
                    Surface(
                        Modifier.fillMaxSize(),
                        color = Color.Transparent,
                        contentColor = MaterialTheme.colorScheme.onBackground
                    ) { App() }
                }
            }
        }
    }
}

private object Brush {
    fun vert() = androidx.compose.ui.graphics.Brush.verticalGradient(
        listOf(Color(0x330A1830), Color(0x4A08152E), Color(0x66060D20))
    )
}

private val Accent = Color(0xFF8FC4FF)
private val NetChanColors = darkColorScheme(
    primary = Accent,
    onPrimary = Color(0xFF07152E),
    secondary = Color(0xFFB9C8E8),
    background = Color(0xFF16284A),
    onBackground = Color(0xFFEAF1FF),
    surface = Color(0xFF1B2F55),
    onSurface = Color(0xFFEAF1FF),
    surfaceVariant = Color(0xFF263E6B),
    onSurfaceVariant = Color(0xFFC3D2EE),
    outline = Color(0xFF6E8CC4)
)
private val NetChanType = Typography(
    titleLarge = Typography().titleLarge.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp),
    titleMedium = Typography().titleMedium.copy(fontWeight = FontWeight.SemiBold)
)

data class ToolMeta(val label: String, val icon: String, val desc: String)

val TOOLS = listOf(
    ToolMeta("Info", "🌐", "Ringkasan koneksi, IP, DNS, Wi-Fi, dan IP publik"),
    ToolMeta("Seluler", "📶", "Detail sel/BTS: RSRP, SINR, band, cell ID"),
    ToolMeta("Ping", "🏓", "Latensi, jitter, packet loss ke host tujuan"),
    ToolMeta("Traceroute", "🛣️", "Jalur hop paket menuju tujuan"),
    ToolMeta("Speed Test", "⚡", "Download, upload, ping, dan bufferbloat"),
    ToolMeta("DNS", "🔎", "Lookup record DNS dan benchmark server DNS"),
    ToolMeta("Web/SSL", "🔒", "Analisis TLS, sertifikat, dan header HTTP"),
    ToolMeta("Port Scan", "🚪", "Memindai port terbuka pada host"),
    ToolMeta("Banner Grab", "🏷️", "Mengintip banner layanan di port terbuka"),
    ToolMeta("LAN Scan", "🖧", "Menemukan perangkat aktif di jaringan lokal"),
    ToolMeta("Discovery", "📡", "Mencari perangkat UPnP (router, TV, speaker)"),
    ToolMeta("Wi-Fi", "📻", "Daftar AP sekitar dan kepadatan kanal"),
    ToolMeta("Sinyal Live", "📈", "Pantau kekuatan sinyal secara real-time"),
    ToolMeta("Cek Layanan", "✅", "Status dan waktu respons situs populer"),
    ToolMeta("Monitor", "📊", "Kecepatan transfer data real-time"),
    ToolMeta("IP Lookup", "📍", "Info lokasi, ASN, dan ISP dari sebuah IP"),
    ToolMeta("Wake-on-LAN", "⏰", "Membangunkan perangkat lewat magic packet"),
    ToolMeta("Subnet Calc", "🧮", "Menghitung network, broadcast, dan range host"),
    ToolMeta("Riwayat", "🕘", "Riwayat hasil Speed Test sebelumnya")
)

/** Menjalankan tugas jaringan dan menampung log keluaran. */
class Runner(private val scope: CoroutineScope) {
    var running by mutableStateOf(false)
        private set
    val log = mutableStateListOf<String>()
    private var job: Job? = null

    fun add(s: String) {
        scope.launch(Dispatchers.Main) {
            log.add(s)
            if (log.size > 600) log.removeAt(0)
        }
    }

    fun start(block: suspend () -> Unit) {
        if (running) return
        log.clear()
        running = true
        job = scope.launch {
            try { block() }
            catch (e: CancellationException) { add("-- dihentikan --"); throw e }
            catch (e: Exception) { add("Error: ${e.message}") }
            finally { running = false }
        }
    }

    fun stop() { job?.cancel() }
}

@Composable
fun rememberRunner(): Runner {
    val scope = rememberCoroutineScope()
    return remember { Runner(scope) }
}

@Composable
fun ToolHeader(meta: ToolMeta) {
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(meta.icon, fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text(meta.label, style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        Spacer(Modifier.height(2.dp))
        Text(meta.desc, style = MaterialTheme.typography.bodySmall, color = Color(0xFFAFC0E6))
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x332E5090)))
    }
}

private sealed class DisplayLine {
    data class Section(val text: String) : DisplayLine()
    data class Kv(val key: String, val value: String) : DisplayLine()
    data class Plain(val text: String) : DisplayLine()
    object Blank : DisplayLine()
}

private val sectionRe = Regex("^==\\s*(.+?)\\s*==\$")
private val kvRe = Regex("^(\\S.*?)\\s*:\\s+(\\S.*)\$")

private fun parseDisplay(lines: List<String>): List<DisplayLine> = lines.map { raw ->
    val t = raw.trim()
    when {
        t.isEmpty() -> DisplayLine.Blank
        sectionRe.matches(t) -> DisplayLine.Section(sectionRe.find(t)!!.groupValues[1])
        kvRe.matches(t) -> {
            val m = kvRe.find(t)!!
            DisplayLine.Kv(m.groupValues[1], m.groupValues[2])
        }
        else -> DisplayLine.Plain(raw)
    }
}

@Composable
fun LogBox(lines: List<String>, modifier: Modifier) {
    val sc = rememberScrollState()
    LaunchedEffect(lines.size) { sc.animateScrollTo(sc.maxValue) }
    val parsed = remember(lines) { parseDisplay(lines) }
    Surface(
        modifier,
        color = Color(0x8A0B1730),
        contentColor = Color(0xFFE8EEFA),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, Color(0x262E5090))
    ) {
        if (lines.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                Text("Hasil akan muncul di sini", color = Color(0xFF7E92C0), textAlign = TextAlign.Center)
            }
        } else {
            SelectionContainer {
                Column(Modifier.fillMaxWidth().verticalScroll(sc).padding(12.dp)) {
                    parsed.forEach { d ->
                        when (d) {
                            is DisplayLine.Section -> {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    d.text.uppercase(), color = Accent, fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp
                                )
                                Spacer(Modifier.height(4.dp))
                                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x2A8FC4FF)))
                                Spacer(Modifier.height(4.dp))
                            }
                            is DisplayLine.Kv -> {
                                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                    Text(
                                        d.key, color = Color(0xFF9FB3DE), fontSize = 12.sp,
                                        modifier = Modifier.weight(0.4f)
                                    )
                                    Text(
                                        d.value, color = Color(0xFFEAF1FF), fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.weight(0.6f)
                                    )
                                }
                            }
                            is DisplayLine.Plain -> {
                                Text(
                                    d.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                                    lineHeight = 17.sp, color = Color(0xFFE8EEFA)
                                )
                            }
                            DisplayLine.Blank -> Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0x5A0B1730),
            unfocusedContainerColor = Color(0x4A0B1730),
            focusedBorderColor = Accent,
            unfocusedBorderColor = Color(0xFF3E5890)
        )
    )
}

@Composable
fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        options.forEach { o ->
            if (o == selected) {
                Button(
                    onClick = { onSelect(o) }, contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF07152E))
                ) { Text(o) }
            } else {
                OutlinedButton(
                    onClick = { onSelect(o) }, contentPadding = PaddingValues(horizontal = 14.dp),
                    border = BorderStroke(1.dp, Color(0xFF3E5890))
                ) { Text(o) }
            }
        }
    }
}

@Composable
fun ToolLayout(
    meta: ToolMeta,
    r: Runner,
    runLabel: String,
    onRun: () -> Unit,
    extra: @Composable RowScope.() -> Unit = {},
    inputs: @Composable ColumnScope.() -> Unit = {}
) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        ToolHeader(meta)
        inputs()
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onRun, enabled = !r.running,
                colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF07152E))
            ) { Text(runLabel) }
            extra()
            OutlinedButton(onClick = { r.stop() }, enabled = r.running, border = BorderStroke(1.dp, Color(0xFF3E5890))) { Text("Stop") }
            OutlinedButton(onClick = { clip.setText(AnnotatedString(r.log.joinToString("\n"))) }, border = BorderStroke(1.dp, Color(0xFF3E5890))) { Text("Salin") }
            OutlinedButton(onClick = {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, r.log.joinToString("\n"))
                }
                ctx.startActivity(Intent.createChooser(i, "Bagikan hasil"))
            }, border = BorderStroke(1.dp, Color(0xFF3E5890))) { Text("Bagikan") }
        }
        if (r.running) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)), color = Accent, trackColor = Color(0x332E5090))
        }
        Spacer(Modifier.height(8.dp))
        LogBox(r.log, Modifier.weight(1f).fillMaxWidth())
    }
}

@Composable
fun Hint(text: String) {
    Text(text, style = MaterialTheme.typography.bodySmall, color = Color(0xFFC3D2EE), modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
fun App() {
    var sel by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("❄️", fontSize = 18.sp)
            Spacer(Modifier.width(8.dp))
            Text("Net-Chan", style = MaterialTheme.typography.titleLarge, color = Color.White)
            Spacer(Modifier.width(6.dp))
            Text("Network Toolkit", style = MaterialTheme.typography.bodySmall, color = Color(0xFF9FB3DE))
        }
        ScrollableTabRow(
            selectedTabIndex = sel,
            edgePadding = 12.dp,
            containerColor = Color(0x660B1730),
            contentColor = Accent
        ) {
            TOOLS.forEachIndexed { i, t ->
                Tab(
                    selected = sel == i, onClick = { sel = i },
                    text = { Text(t.label, fontSize = 12.sp) },
                    icon = { Text(t.icon, fontSize = 14.sp) },
                    unselectedContentColor = Color(0xFF9FB3DE)
                )
            }
        }
        when (sel) {
            0 -> InfoTab(); 1 -> CellTab(); 2 -> PingTab(); 3 -> TraceTab(); 4 -> SpeedTab()
            5 -> DnsTab(); 6 -> WebTab(); 7 -> PortTab(); 8 -> BannerTab(); 9 -> LanTab()
            10 -> DiscoveryTab(); 11 -> WifiTab(); 12 -> SignalTab(); 13 -> ServiceTab(); 14 -> MonitorTab()
            15 -> IpTab(); 16 -> WolTab(); 17 -> SubnetTab(); 18 -> HistoryTab()
        }
    }
}

@Composable
fun InfoTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    val run = {
        r.start {
            r.add("== PERANGKAT ==")
            NetInfo.local(ctx).forEach { r.add(it) }
            r.add(""); r.add("== IP PUBLIK ==")
            NetInfo.publicIp().forEach { r.add(it) }
            NetInfo.ipVersions().forEach { r.add(it) }
        }
    }
    LaunchedEffect(Unit) { run() }
    ToolLayout(TOOLS[0], r, "Muat ulang", run)
}

@Composable
fun CellTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    val run = { r.start { NetInfo.cellular(ctx).forEach { r.add(it) } } }
    LaunchedEffect(Unit) { run() }
    ToolLayout(TOOLS[1], r, "Muat ulang", run)
}

@Composable
fun PingTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("8.8.8.8") }
    var count by rememberSaveable { mutableStateOf("10") }
    ToolLayout(TOOLS[2], r, "Mulai Ping", {
        r.start { NetTools.ping(host.trim(), (count.toIntOrNull() ?: 10).coerceIn(1, 100)) { r.add(it) } }
    }) {
        Field(host, { host = it }, "Host / IP")
        Field(count, { count = it }, "Jumlah paket (1-100)")
    }
}

@Composable
fun TraceTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("google.com") }
    ToolLayout(TOOLS[3], r, "Mulai Traceroute", {
        r.start { NetTools.trace(host.trim(), 30) { r.add(it) } }
    }) { Field(host, { host = it }, "Host / IP tujuan") }
}

@Composable
fun SpeedTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(TOOLS[4], r, "Mulai Speed Test", {
        r.start {
            val res = NetTools.speedTest { r.add(it) }
            if (res != null) {
                History.add(ctx, res, NetInfo.networkLabel(ctx))
                r.add("Hasil tersimpan di tab Riwayat.")
            }
        }
    }) {
        Hint("Mengukur latensi, jitter, download, upload, dan bufferbloat (latensi saat jaringan penuh) memakai server Cloudflare. Memakai kuota data.")
    }
}

@Composable
fun DnsTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("google.com") }
    var type by rememberSaveable { mutableStateOf("A") }
    var server by rememberSaveable { mutableStateOf("") }
    ToolLayout(TOOLS[5], r, "Lookup", {
        r.start {
            val srv = server.trim().ifEmpty { NetInfo.activeDns(ctx).firstOrNull() ?: "8.8.8.8" }
            DnsClient.lookup(srv, host.trim(), type) { r.add(it) }
        }
    }, extra = {
        OutlinedButton(
            onClick = { r.start { DnsClient.benchmark(NetInfo.activeDns(ctx)) { r.add(it) } } },
            enabled = !r.running, border = BorderStroke(1.dp, Color(0xFF3E5890))
        ) { Text("Benchmark DNS") }
    }) {
        Field(host, { host = it }, "Domain")
        ChoiceRow(DnsClient.TYPES.keys.toList(), type) { type = it }
        Field(server, { server = it }, "Server DNS (kosong = DNS jaringan saat ini)")
    }
}

@Composable
fun WebTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("www.google.com") }
    ToolLayout(TOOLS[6], r, "Analisis", { r.start { Inspector.web(host, { r.add(it) }) } }) {
        Field(host, { host = it }, "Domain (atau domain:port)")
    }
}

@Composable
fun PortTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("scanme.nmap.org") }
    var ports by rememberSaveable { mutableStateOf("common") }
    ToolLayout(TOOLS[7], r, "Mulai Scan", {
        r.start { NetTools.portScan(host.trim(), NetTools.parsePorts(ports)) { r.add(it) } }
    }) {
        Field(host, { host = it }, "Host / IP")
        Field(ports, { ports = it }, "Port (common, atau 22,80,443 atau 1-1024)")
        Hint("Hanya pindai perangkat/server milik sendiri atau yang Anda punya izin.")
    }
}

@Composable
fun BannerTab() {
    val r = rememberRunner()
    var host by rememberSaveable { mutableStateOf("") }
    var ports by rememberSaveable { mutableStateOf("21,22,23,25,80,110,143,3306,8080") }
    ToolLayout(TOOLS[8], r, "Ambil Banner", {
        r.start { Extras.bannerGrab(host.trim(), ports) { r.add(it) } }
    }) {
        Field(host, { host = it }, "Host / IP")
        Field(ports, { ports = it }, "Port")
        Hint("Hanya pakai pada perangkat/server milik sendiri atau yang Anda punya izin.")
    }
}

@Composable
fun LanTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(TOOLS[9], r, "Pindai LAN", { r.start { NetTools.lanScan(ctx) { r.add(it) } } })
}

@Composable
fun DiscoveryTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(TOOLS[10], r, "Cari Perangkat", { r.start { Inspector.ssdp(ctx) { r.add(it) } } }) {
        Hint("Mencari router, Smart TV, speaker, printer, dan perangkat UPnP lain lewat SSDP. Harus terhubung ke Wi-Fi.")
    }
}

@Composable
fun WifiTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(TOOLS[11], r, "Pindai Wi-Fi", { r.start { NetInfo.wifiScan(ctx) { r.add(it) } } })
}

@Composable
fun SignalTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    ToolLayout(TOOLS[12], r, "Mulai Pantau", { r.start { NetInfo.liveSignal(ctx) { r.add(it) } } })
}

@Composable
fun ServiceTab() {
    val r = rememberRunner()
    ToolLayout(TOOLS[13], r, "Cek Layanan", { r.start { NetTools.httpCheck(NetTools.DEFAULT_SITES) { r.add(it) } } })
}

@Composable
fun MonitorTab() {
    val r = rememberRunner()
    ToolLayout(TOOLS[14], r, "Mulai Monitor", { r.start { NetTools.monitor { r.add(it) } } })
}

@Composable
fun IpTab() {
    val r = rememberRunner()
    var target by rememberSaveable { mutableStateOf("") }
    ToolLayout(TOOLS[15], r, "Cari Info IP", { r.start { Inspector.ipLookup(target) { r.add(it) } } }) {
        Field(target, { target = it }, "IP / domain (kosong = IP publik saya)")
    }
}

@Composable
fun WolTab() {
    val r = rememberRunner()
    var mac by rememberSaveable { mutableStateOf("") }
    var ip by rememberSaveable { mutableStateOf("255.255.255.255") }
    var port by rememberSaveable { mutableStateOf("9") }
    ToolLayout(TOOLS[16], r, "Kirim Magic Packet", {
        r.start { Extras.wakeOnLan(mac, ip, port.toIntOrNull() ?: 9) { r.add(it) } }
    }) {
        Field(mac, { mac = it }, "MAC address (AA:BB:CC:DD:EE:FF)")
        Field(ip, { ip = it }, "IP broadcast (contoh 192.168.1.255)")
        Field(port, { port = it }, "Port (biasanya 9)")
    }
}

@Composable
fun SubnetTab() {
    val r = rememberRunner()
    var cidr by rememberSaveable { mutableStateOf("192.168.1.10/24") }
    ToolLayout(TOOLS[17], r, "Hitung", {
        r.start { Extras.subnetCalc(cidr) { r.add(it) } }
    }) { Field(cidr, { cidr = it }, "IP/Prefix, contoh 192.168.1.10/24") }
}

@Composable
fun HistoryTab() {
    val ctx = LocalContext.current
    val r = rememberRunner()
    val run = {
        r.start {
            val l = History.lines(ctx)
            if (l.isEmpty()) r.add("Belum ada riwayat. Jalankan Speed Test dulu.") else l.forEach { r.add(it) }
        }
    }
    LaunchedEffect(Unit) { run() }
    ToolLayout(TOOLS[18], r, "Muat ulang", run, extra = {
        OutlinedButton(onClick = { History.clear(ctx); run() }, enabled = !r.running, border = BorderStroke(1.dp, Color(0xFF3E5890))) { Text("Hapus riwayat") }
    })
}
